(() => {
  const root = document.querySelector('[data-arrival-estimator]');
  if (!root) return;
  const dateInput = root.querySelector('[name="delivered-date"]');
  const timeInput = root.querySelector('[name="delivered-time"]');
  const result = root.querySelector('[data-arrival-result]');
  const cycle = root.querySelector('[data-arrival-cycle]');
  const note = root.querySelector('[data-arrival-note]');
  const todayBtn = root.querySelector('[data-set-today]');

  const parseDate = value => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return null;
    const [y,m,d] = value.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d));
    return Number.isNaN(dt.getTime()) ? null : dt;
  };
  const addDays = (date, days) => {
    const copy = new Date(date.getTime());
    copy.setUTCDate(copy.getUTCDate() + days);
    return copy;
  };
  const fmt = date => new Intl.DateTimeFormat('en-US', {
    weekday:'short', month:'short', day:'numeric', year:'numeric', timeZone:'UTC'
  }).format(date);
  const toDateInput = date => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2,'0');
    const d = String(date.getDate()).padStart(2,'0');
    return `${y}-${m}-${d}`;
  };
  const rangeText = saturday => `${fmt(addDays(saturday,5))} – ${fmt(addDays(saturday,6))}`;

  const update = () => {
    const delivered = parseDate(dateInput.value);
    if (!delivered) {
      result.textContent = 'Choose a delivery date';
      cycle.textContent = 'AMC will estimate the normal weekly cycle.';
      note.textContent = 'The estimate is based on AMC’s Saturday 2:30 PM US warehouse cutoff.';
      return;
    }
    const dow = delivered.getUTCDay();
    const time = timeInput.value || '';

    if (dow === 6 && !time) {
      const sameCycle = delivered;
      const nextCycle = addDays(delivered, 7);
      result.textContent = `${rangeText(sameCycle)} OR ${rangeText(nextCycle)}`;
      cycle.textContent = 'Saturday delivery — delivery time matters.';
      note.textContent = 'If the carrier delivered by 2:30 PM New York time, use the first range. If it delivered after 2:30 PM, use the second range. Add the delivery time above for one estimate.';
      return;
    }

    let daysToSaturday = (6 - dow + 7) % 7;
    if (dow === 6 && time) {
      const [hh,mm] = time.split(':').map(Number);
      const minutes = (hh || 0) * 60 + (mm || 0);
      if (minutes > (14 * 60 + 30)) daysToSaturday = 7;
    }
    const cutoffSaturday = addDays(delivered, daysToSaturday);
    result.textContent = rangeText(cutoffSaturday);
    cycle.textContent = `Likely shipment cutoff: ${fmt(cutoffSaturday)} · 2:30 PM New York time`;
    note.textContent = daysToSaturday === 7
      ? 'This delivery missed the Saturday cutoff, so the estimate rolls to the next weekly shipment cycle.'
      : 'This estimate follows AMC’s normal weekly air-freight cycle. Airline, warehouse, customs and clearance delays can change the final date.';
  };

  dateInput.addEventListener('input', update);
  timeInput.addEventListener('input', update);
  todayBtn?.addEventListener('click', () => {
    dateInput.value = toDateInput(new Date());
    update();
  });
  update();
})();
