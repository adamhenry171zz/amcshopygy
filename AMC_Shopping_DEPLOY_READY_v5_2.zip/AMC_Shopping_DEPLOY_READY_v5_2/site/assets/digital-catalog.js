window.AMC_DIGITAL_CATALOG = [
  {
    "section": "TikTok Coins",
    "sectionNote": "TikTok web recharge packages from GYD $5,000 upward. Final availability can vary by account, region and TikTok checkout pricing.",
    "items": [
      {
        "name": "TikTok Coins",
        "eyebrow": "Social / Creator Credit",
        "tag": "POPULAR",
        "packages": [
          {
            "label": "1,400 Coins",
            "price": "GYD $5,000"
          },
          {
            "label": "3,500 Coins",
            "price": "GYD $13,000"
          },
          {
            "label": "7,000 Coins",
            "price": "GYD $26,000"
          },
          {
            "label": "17,500 Coins",
            "price": "GYD $65,000"
          },
          {
            "label": "Custom / larger amount",
            "price": "Request current price"
          }
        ],
        "note": "TikTok coin package availability and checkout pricing may vary. AMC confirms the final amount before payment."
      }
    ]
  },
  {
    "section": "Games & Game Credit",
    "sectionNote": "Popular game top-ups and wallet codes. Region compatibility is checked before payment.",
    "items": [
      {
        "name": "Razer Gold",
        "eyebrow": "Gift Cards",
        "packages": [
          {
            "label": "$5 USD",
            "price": "GYD $1,500"
          },
          {
            "label": "$10 USD",
            "price": "GYD $3,000"
          },
          {
            "label": "$20 USD",
            "price": "GYD $5,500"
          },
          {
            "label": "$25 USD",
            "price": "GYD $7,000"
          },
          {
            "label": "$50 USD",
            "price": "GYD $12,500"
          },
          {
            "label": "$100 USD",
            "price": "GYD $25,000"
          },
          {
            "label": "$200 USD",
            "price": "GYD $50,000"
          },
          {
            "label": "$300 USD",
            "price": "GYD $75,000"
          },
          {
            "label": "$400 USD",
            "price": "GYD $100,000"
          },
          {
            "label": "$500 USD",
            "price": "GYD $125,000"
          }
        ]
      },
      {
        "name": "Roblox",
        "eyebrow": "US Gift Cards",
        "packages": [
          {
            "label": "$10 USD",
            "price": "GYD $3,000"
          },
          {
            "label": "$20 USD",
            "price": "GYD $5,500"
          },
          {
            "label": "$25 USD",
            "price": "GYD $7,000"
          },
          {
            "label": "$50 USD",
            "price": "GYD $12,500"
          },
          {
            "label": "$100 USD",
            "price": "GYD $25,000"
          }
        ]
      },
      {
        "name": "Free Fire LATAM",
        "eyebrow": "Diamonds",
        "packages": [
          {
            "label": "100 + 10 Diamonds",
            "price": "GYD $500"
          },
          {
            "label": "310 + 31 Diamonds",
            "price": "GYD $1,000"
          },
          {
            "label": "520 + 52 Diamonds",
            "price": "GYD $1,500"
          },
          {
            "label": "1060 + 106 Diamonds",
            "price": "GYD $2,500"
          },
          {
            "label": "2180 + 218 Diamonds",
            "price": "GYD $4,000"
          }
        ]
      },
      {
        "name": "PUBG Mobile Global",
        "eyebrow": "UC",
        "packages": [
          {
            "label": "60 UC",
            "price": "GYD $500"
          },
          {
            "label": "300 + 25 UC",
            "price": "GYD $1,500"
          },
          {
            "label": "600 + 60 UC",
            "price": "GYD $3,000"
          },
          {
            "label": "1500 + 300 UC",
            "price": "GYD $6,500"
          },
          {
            "label": "3000 + 850 UC",
            "price": "GYD $12,500"
          },
          {
            "label": "6000 + 2100 UC",
            "price": "GYD $25,000"
          }
        ]
      },
      {
        "name": "Mobile Legends",
        "eyebrow": "Diamonds",
        "packages": [
          {
            "label": "55 Diamonds",
            "price": "GYD $500"
          },
          {
            "label": "165 Diamonds",
            "price": "GYD $1,200"
          },
          {
            "label": "275 Diamonds",
            "price": "GYD $1,800"
          },
          {
            "label": "565 Diamonds",
            "price": "GYD $3,500"
          },
          {
            "label": "1825 Diamonds",
            "price": "GYD $8,000"
          }
        ]
      },
      {
        "name": "Blood Strike",
        "eyebrow": "Gold",
        "packages": [
          {
            "label": "100 + 16 Gold",
            "price": "GYD $500"
          },
          {
            "label": "300 + 52 Gold",
            "price": "GYD $1,000"
          },
          {
            "label": "500 + 94 Gold",
            "price": "GYD $1,500"
          },
          {
            "label": "1000 + 210 Gold",
            "price": "GYD $2,800"
          },
          {
            "label": "2000 + 486 Gold",
            "price": "GYD $5,000"
          },
          {
            "label": "5000 + 1380 Gold",
            "price": "GYD $11,500"
          }
        ]
      },
      {
        "name": "PlayStation US",
        "eyebrow": "PSN Gift Cards",
        "packages": [
          {
            "label": "$25 PSN",
            "price": "GYD $7,000"
          },
          {
            "label": "$50 PSN",
            "price": "GYD $12,500"
          },
          {
            "label": "$100 PSN",
            "price": "GYD $25,000"
          }
        ]
      },
      {
        "name": "Steam USD",
        "eyebrow": "Wallet Codes",
        "packages": [
          {
            "label": "$5 Wallet",
            "price": "GYD $1,500"
          },
          {
            "label": "$10 Wallet",
            "price": "GYD $3,000"
          },
          {
            "label": "$20 Wallet",
            "price": "GYD $5,500"
          },
          {
            "label": "$50 Wallet",
            "price": "GYD $12,500"
          },
          {
            "label": "$100 Wallet",
            "price": "GYD $25,000"
          }
        ]
      },
      {
        "name": "Fortnite",
        "eyebrow": "Gift Card / V-Bucks",
        "packages": [
          {
            "label": "$15 USD",
            "price": "Request current price"
          },
          {
            "label": "$30 USD",
            "price": "Request current price"
          },
          {
            "label": "$50 USD",
            "price": "Request current price"
          },
          {
            "label": "$100 USD",
            "price": "Request current price"
          }
        ],
        "note": "Fortnite cards are region/currency specific. AMC confirms compatibility first."
      },
      {
        "name": "Xbox US",
        "eyebrow": "Xbox Gift Card",
        "packages": [
          {
            "label": "$25 USD",
            "price": "Request current price"
          },
          {
            "label": "$50 USD",
            "price": "Request current price"
          },
          {
            "label": "$100 USD",
            "price": "Request current price"
          }
        ]
      },
      {
        "name": "Nintendo eShop US",
        "eyebrow": "Nintendo Gift Card",
        "packages": [
          {
            "label": "$20 USD",
            "price": "Request current price"
          },
          {
            "label": "$50 USD",
            "price": "Request current price"
          },
          {
            "label": "$100 USD",
            "price": "Request current price"
          }
        ]
      }
    ]
  },
  {
    "section": "Shopping & App Gift Cards",
    "sectionNote": "US-region digital gift cards. Because supplier prices move, AMC confirms the current selling price before payment unless a fixed AMC price is shown.",
    "items": [
      {
        "name": "Amazon Gift Card US",
        "eyebrow": "Shopping",
        "packages": [
          {
            "label": "$25 USD",
            "price": "Request current price"
          },
          {
            "label": "$50 USD",
            "price": "Request current price"
          },
          {
            "label": "$100 USD",
            "price": "Request current price"
          }
        ],
        "note": "Valid for Amazon.com US only."
      },
      {
        "name": "SHEIN E-Gift Card US",
        "eyebrow": "Fashion / Shopping",
        "packages": [
          {
            "label": "$25 USD",
            "price": "Request current price"
          },
          {
            "label": "$50 USD",
            "price": "Request current price"
          },
          {
            "label": "$80 USD",
            "price": "Request current price"
          },
          {
            "label": "$100 USD",
            "price": "Request current price"
          },
          {
            "label": "$200+ USD",
            "price": "Request current price"
          }
        ],
        "note": "SHEIN gift cards are region-specific. US card for US SHEIN account/store."
      },
      {
        "name": "Apple Gift Card US",
        "eyebrow": "Apps / Apple",
        "packages": [
          {
            "label": "$25 USD",
            "price": "Request current price"
          },
          {
            "label": "$50 USD",
            "price": "Request current price"
          },
          {
            "label": "$100 USD",
            "price": "Request current price"
          }
        ],
        "note": "For Apple accounts registered in the United States."
      },
      {
        "name": "Google Play Gift Card US",
        "eyebrow": "Apps / Google Play",
        "packages": [
          {
            "label": "$25 USD",
            "price": "Request current price"
          },
          {
            "label": "$50 USD",
            "price": "Request current price"
          },
          {
            "label": "$100 USD",
            "price": "Request current price"
          }
        ],
        "note": "For Google Play accounts registered in the United States."
      }
    ]
  },
  {
    "section": "Streaming & Entertainment",
    "sectionNote": "Current AMC streaming plans. Netflix accounts are private; Disney+ and Prime are shared-access services. Select a package to send a request.",
    "items": [
      {
        "name": "Netflix Basic",
        "eyebrow": "Private Account",
        "tag": "NETFLIX",
        "packages": [
          {
            "label": "90 Days",
            "price": "GYD $6,500"
          },
          {
            "label": "120 Days",
            "price": "GYD $8,500"
          },
          {
            "label": "150 Days",
            "price": "GYD $10,000"
          },
          {
            "label": "180 Days",
            "price": "GYD $12,000"
          }
        ],
        "note": "Private Netflix account."
      },
      {
        "name": "Netflix Standard",
        "eyebrow": "Private Account",
        "tag": "NETFLIX",
        "packages": [
          {
            "label": "60 Days",
            "price": "GYD $6,500"
          },
          {
            "label": "90 Days",
            "price": "GYD $9,500"
          },
          {
            "label": "120 Days",
            "price": "GYD $12,500"
          },
          {
            "label": "150 Days",
            "price": "GYD $15,000"
          },
          {
            "label": "180 Days",
            "price": "GYD $18,000"
          }
        ],
        "note": "Private Netflix account."
      },
      {
        "name": "Netflix Premium",
        "eyebrow": "Private Account · 4K",
        "tag": "NETFLIX",
        "packages": [
          {
            "label": "30 Days",
            "price": "GYD $5,000"
          },
          {
            "label": "60 Days",
            "price": "GYD $9,500"
          },
          {
            "label": "90 Days",
            "price": "GYD $14,000"
          },
          {
            "label": "120 Days",
            "price": "GYD $18,500"
          },
          {
            "label": "150 Days",
            "price": "GYD $22,500"
          },
          {
            "label": "180 Days",
            "price": "GYD $26,500"
          }
        ],
        "note": "Private Netflix account."
      },
      {
        "name": "Netflix Extra Member Add-On",
        "eyebrow": "Netflix Add-On",
        "packages": [
          {
            "label": "30 Days",
            "price": "GYD $1,500"
          }
        ],
        "note": "Extra member add-on for an eligible Netflix plan."
      },
      {
        "name": "Disney+",
        "eyebrow": "Shared Access",
        "packages": [
          {
            "label": "30 Days",
            "price": "GYD $2,000"
          }
        ],
        "note": "Shared-access service. 14-day limited warranty from activation."
      },
      {
        "name": "Prime Video",
        "eyebrow": "Shared Access",
        "packages": [
          {
            "label": "30 Days",
            "price": "GYD $2,000"
          }
        ],
        "note": "Shared-access service. 14-day limited warranty from activation."
      },
      {
        "name": "Disney+ + Prime Bundle",
        "eyebrow": "Streaming Bundle",
        "tag": "VALUE",
        "packages": [
          {
            "label": "30 Days",
            "price": "GYD $3,500"
          }
        ],
        "note": "Shared-access bundle. 14-day limited warranty from activation."
      },
      {
        "name": "IPTV",
        "eyebrow": "Live TV / Entertainment",
        "packages": [
          {
            "label": "30 Days",
            "price": "GYD $3,500"
          }
        ],
        "note": "A stable internet speed of 20 Mbps or higher is recommended."
      },
      {
        "name": "Crunchyroll",
        "eyebrow": "Anime Streaming",
        "packages": [
          {
            "label": "Current Plan",
            "price": "Inquire for pricing"
          }
        ]
      },
      {
        "name": "Other Streaming Service",
        "eyebrow": "Request",
        "packages": [
          {
            "label": "Tell AMC what you need",
            "price": "Request current price"
          }
        ]
      }
    ]
  }
];
