(() => {
  const catalogRoot = document.querySelector('#digital-catalog');
  const streamingRoot = document.querySelector('#streaming-plans');
  const form = document.querySelector('#topup-form');
  const catalog = Array.isArray(window.AMC_DIGITAL_CATALOG) ? window.AMC_DIGITAL_CATALOG : [];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch]));
  const streamingSection = catalog.find(section => section.section === 'Streaming & Entertainment');
  const otherSections = catalog.filter(section => section !== streamingSection);

  const itemCard = (item, itemIndex, extraClass = '') => `
    <article class="topup-card ${extraClass}">
      <div class="topup-head"><div><small>${esc(item.eyebrow || 'Digital')}</small><h3>${esc(item.name)}</h3>${item.tag ? `<span class="catalog-badge">${esc(item.tag)}</span>` : ''}</div><span>${String(itemIndex + 1).padStart(2,'0')}</span></div>
      <div class="price-list">
        ${(item.packages || []).map(pkg => `<div class="price-row"><span>${esc(pkg.label)}</span><strong>${esc(pkg.price)}</strong><button type="button" class="mini-select" data-topup-select data-service="${esc(item.name)}" data-package="${esc(pkg.label)}" data-price="${esc(pkg.price)}">Select</button></div>`).join('')}
      </div>
      ${item.note ? `<p class="catalog-note">${esc(item.note)}</p>` : ''}
    </article>`;

  if (streamingRoot && streamingSection) {
    streamingRoot.innerHTML = (streamingSection.items || []).map((item, i) => itemCard(item, i, 'streaming-plan-card')).join('');
  }

  if (catalogRoot) {
    catalogRoot.innerHTML = otherSections.map((section, sectionIndex) => `
      <section class="catalog-group" aria-labelledby="catalog-${sectionIndex}">
        <div class="catalog-title-row">
          <div><div class="kicker">${esc(section.section)}</div><h3 id="catalog-${sectionIndex}">${esc(section.section)}</h3></div>
          <p>${esc(section.sectionNote || '')}</p>
        </div>
        <div class="topup-grid">
          ${(section.items || []).map((item, itemIndex) => itemCard(item, itemIndex)).join('')}
        </div>
      </section>`).join('');
  }

  if (!form) return;
  const service = form.elements['service'];
  const pkg = form.elements['package'];
  const price = form.elements['amc-price'];
  const names = [...new Set(catalog.flatMap(section => (section.items || []).map(item => item.name)))];
  names.forEach(name => {
    const option = document.createElement('option');
    option.value = name; option.textContent = name;
    service.appendChild(option);
  });

  document.querySelectorAll('[data-topup-select]').forEach(btn => btn.addEventListener('click', () => {
    service.value = btn.dataset.service || '';
    pkg.value = btn.dataset.package || '';
    price.value = btn.dataset.price || '';
    document.querySelector('#topup-request')?.scrollIntoView({behavior:'smooth', block:'start'});
    pkg.focus();
  }));
})();
