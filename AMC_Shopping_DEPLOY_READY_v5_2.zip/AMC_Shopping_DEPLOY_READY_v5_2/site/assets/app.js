(() => {
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
  const menu = document.querySelector('.menu-btn');
  const nav = document.querySelector('.nav-links');
  if (menu && nav) {
    menu.addEventListener('click', () => {
      nav.classList.toggle('open');
      menu.setAttribute('aria-expanded', nav.classList.contains('open') ? 'true' : 'false');
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
  }
  document.querySelectorAll('a[href]').forEach(link => {
    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('tel:') || link.target === '_blank') return;
    link.addEventListener('click', e => {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      e.preventDefault();
      document.body.style.opacity = '.15';
      document.body.style.transform = 'translateY(4px)';
      document.body.style.transition = 'opacity .16s ease, transform .16s ease';
      setTimeout(() => { window.location.href = href; }, 130);
    });
  });
  const money = n => new Intl.NumberFormat('en-US',{maximumFractionDigits:0}).format(Math.round(n));
  document.querySelectorAll('[data-shipping-calculator]').forEach(calc => {
    const weight = calc.querySelector('[name="weight"]');
    const standardResult = calc.querySelector('[data-standard-result]');
    const memberResult = calc.querySelector('[data-member-result]');
    const savingResult = calc.querySelector('[data-saving-result]');
    const standardExplain = calc.querySelector('[data-standard-explain]');
    const update = () => {
      let raw = Math.max(parseFloat(weight?.value) || 0, 0);
      if (!raw) {
        standardResult.textContent = '$0'; memberResult.textContent = '$0'; savingResult.textContent = '$0';
        standardExplain.textContent = 'Enter the combined shipment weight.'; return;
      }
      const w = Math.max(raw, 1);
      let standard, explanation;
      if (w <= 2) { standard = 2800; explanation = 'AMC 1–2 lb flat shipping rate'; }
      else {
        const rate = w <= 10 ? 1500 : (w <= 25 ? 1300 : (w <= 55 ? 1200 : (w <= 99 ? 1100 : 1050)));
        standard = w * rate; explanation = `$${money(rate)} × ${w.toFixed(1)} lbs · no package fee`;
      }
      const member = w * 950;
      standardResult.textContent = '$' + money(standard);
      memberResult.textContent = '$' + money(member);
      savingResult.textContent = '$' + money(Math.max(standard - member, 0));
      standardExplain.textContent = explanation;
    };
    weight?.addEventListener('input', update); update();
  });

  document.querySelectorAll('[data-home-shein-calculator]').forEach(calc => {
    const usdInput = calc.querySelector('[name="shein-item-usd"]');
    const weightInput = calc.querySelector('[name="shein-item-weight"]');
    const result = calc.querySelector('[data-home-shein-result]');
    const message = calc.querySelector('[data-home-shein-message]');
    const shippingFor = weight => {
      const w = Math.max(parseFloat(weight) || 0, 0);
      if (w <= 3) return 0;
      const rate = w <= 10 ? 1500 : (w <= 25 ? 1300 : (w <= 55 ? 1200 : (w <= 99 ? 1100 : 1050)));
      return w * rate;
    };
    const updateShein = () => {
      const usd = Math.max(parseFloat(usdInput?.value) || 0, 0);
      const weight = Math.max(parseFloat(weightInput?.value) || 0, 0);
      const base = usd * 360;
      const shipping = shippingFor(weight);
      result.textContent = 'GYD $' + money(base + shipping);
      message.textContent = weight > 3
        ? `US$${usd.toFixed(2)} × 360 + GYD $${money(shipping)} normal shipping for this item`
        : `US$${usd.toFixed(2)} × GYD $360 · no extra weight charge for this item`;
    };
    usdInput?.addEventListener('input', updateShein);
    weightInput?.addEventListener('input', updateShein);
    updateShein();
  });
})();
