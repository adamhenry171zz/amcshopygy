(() => {
  const form = document.querySelector('#mailbox-generator');
  if (!form) return;
  const status = document.querySelector('[data-mailbox-status]');
  const submit = document.querySelector('[data-mailbox-submit]');
  const box = document.querySelector('[data-generated-mailbox]');
  const addr = document.querySelector('[data-generated-address]');
  const copyBtn = document.querySelector('[data-copy-mailbox]');
  let copyText = '';
  const setStatus = (text, error=false) => { status.textContent = text; status.classList.toggle('error', error); };
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    submit.disabled = true; submit.textContent = 'Generating…'; setStatus('Creating your AMC code…');
    try {
      const res = await fetch('/api/generate-mailbox', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
      const payload = await res.json();
      if (!res.ok) throw new Error(payload.error || 'Could not generate mailbox.');
      document.querySelector('[data-mb-first]').textContent = payload.firstName;
      document.querySelector('[data-mb-last]').textContent = payload.lastNameCheckout;
      document.querySelector('[data-mb-code]').textContent = payload.code;
      copyText = `First name: ${payload.firstName}\nLast name: ${payload.lastNameCheckout}\nAddress Line 1: ${payload.address1}\nAddress Line 2: ${payload.code}\nCity: ${payload.city}\nState: ${payload.state}\nZIP: ${payload.zip}\nCountry: ${payload.country}\nPhone: ${payload.phone}`;
      addr.innerHTML = `<b>${payload.firstName} ${payload.lastNameCheckout}</b><br>${payload.address1}<br>${payload.code}<br>${payload.city}, ${payload.state} ${payload.zip}<br>${payload.country}<br>${payload.phone}`;
      box.hidden = false; setStatus('Mailbox created successfully. Keep this AMC code for future shipments.');
      const formBody = new URLSearchParams({'form-name':'amc-mailbox-issued','first-name':payload.firstName,'last-name':data.lastName,'whatsapp':data.whatsapp,'email':data.email || '','amc-code':payload.code});
      fetch('/', {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:formBody.toString()}).catch(()=>{});
    } catch (err) { setStatus(err.message || 'Something went wrong. Please WhatsApp AMC for help.', true); }
    finally { submit.disabled = false; submit.textContent = 'Generate my mailbox →'; }
  });
  copyBtn?.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(copyText); copyBtn.textContent = 'Copied ✓'; setTimeout(()=>copyBtn.textContent='Copy checkout details',1800); }
    catch { window.prompt('Copy your AMC mailbox details:', copyText); }
  });
})();